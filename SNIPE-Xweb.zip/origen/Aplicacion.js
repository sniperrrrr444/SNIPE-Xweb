import React, { useState } from "react";
import { motion } from "framer-motion";
import { Menu, Bell, Rocket, Users, Clock, Edit3 } from "lucide-react";

// -------------------------------
// EDIT THIS DATA BLOCK to change content easily
// -------------------------------
const CMS = {
  siteTitle: "SNIPE X",
  tagline: "Impulsando lanzamientos experimentales",
  logo: "https://drive.google.com/uc?export=view&id=17gC3YR01K5Hf5uuekwX_I_zFUeEvtTuq",
  hero: {
    title: "SNIPE X",
    subtitle: "Ingeniería espacial accesible. Proyecto open-source.",
    cta: "Ver lanzamientos",
  },
  initialUpdates: [
    { date: "2025-09-30", title: "Prueba de motor completada", body: "Se ha completado la prueba estática del motor 3A. Preparando integración final." },
    { date: "2025-08-12", title: "Nueva telemetría", body: "Sistema de telemetría actualizado con streaming en tiempo real (beta)." },
  ],
  about: {
    summary: "SNIPE X es una iniciativa independiente para diseñar y publicar proyectos de lanzadores reutilizables y educativos. Nuestro objetivo es compartir conocimiento y herramientas para estudiantes y aficionados.",
    team: [
      { name: "SNIPERRRRR444", role: "Fundador & Lead Dev" },
    ],
  },
  launches: [
    { id: "Eagle-9", date: "2026-02-12", status: "Planned", notes: "Demo suborbital con recupero parcial." },
    { id: "Robert-1", date: "2025-12-05", status: "Testing", notes: "Campaña de pruebas en Duna Range." },
  ],
  contact: { email: "hola@snipex.example", github: "github.com/sniperrrr444/snipex" },
};

// -------------------------------
// Utility
// -------------------------------
function SectionTitle({ children, icon: Icon }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      {Icon && <Icon size={20} />}
      <h3 className="text-2xl font-semibold tracking-tight">{children}</h3>
    </div>
  );
}

export default function App() {
  const [updates, setUpdates] = useState(CMS.initialUpdates);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ date: "", title: "", body: "" });
  const [auth, setAuth] = useState(false);
  const [password, setPassword] = useState("");
  const CORRECT_PASSWORD = "Castro013";

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title || !form.body) return;
    const newUpdate = { date: form.date || new Date().toISOString().split("T")[0], title: form.title, body: form.body };
    setUpdates([newUpdate, ...updates]);
    setForm({ date: "", title: "", body: "" });
    setEditing(false);
  };

  const handleAuthSubmit = (e) => {
    e.preventDefault();
    if(password === CORRECT_PASSWORD){
      setAuth(true);
      setPassword("");
      setEditing(true);
    } else {
      alert("Contraseña incorrecta");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white text-slate-900">
      <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {CMS.logo && <img src={CMS.logo} alt="logo" className="h-10 w-20 object-contain" />}
          <div>
            <h1 className="text-2xl md:text-3xl font-extrabold">{CMS.siteTitle}</h1>
            <p className="text-sm text-slate-500">{CMS.tagline}</p>
          </div>
        </div>
        <nav className="hidden md:flex items-center gap-4">
          <a href="#updates" className="text-sm hover:underline">Actualizaciones</a>
          <a href="#about" className="text-sm hover:underline">Quiénes somos</a>
          <a href="#launches" className="text-sm hover:underline">Lanzamientos</a>
          <a href="#contact" className="text-sm font-medium px-3 py-2 rounded-md ring-1 ring-slate-200">Contacto</a>
        </nav>
        <div className="md:hidden">
          <button aria-label="menu" className="p-2 rounded-md ring-1">
            <Menu size={18} />
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 pb-16 space-y-16">
        {/* HERO */}
        <section id="hero" className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center py-8">
          <motion.div initial={{ x: -30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 0.5 }}>
            <h2 className="text-4xl md:text-5xl font-extrabold mb-3">{CMS.hero.title}</h2>
            <p className="text-lg text-slate-600 mb-6">{CMS.hero.subtitle}</p>
            <a href="#launches" className="inline-block px-5 py-3 bg-slate-900 text-white rounded-lg shadow">{CMS.hero.cta}</a>
          </motion.div>

          <motion.div initial={{ x: 30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 0.5 }} className="bg-white rounded-2xl p-6 ring-1 ring-slate-100 shadow-sm">
            <SectionTitle icon={Bell}>Zona de actualizaciones</SectionTitle>
            <div id="updates" className="space-y-4">
              {updates.map((u, i) => (
                <article key={i} className="border rounded-lg p-3 hover:shadow">
                  <div className="flex items-center justify-between">
                    <strong className="block">{u.title}</strong>
                    <time className="text-sm text-slate-400">{u.date}</time>
                  </div>
                  <p className="text-sm text-slate-600 mt-2">{u.body}</p>
                </article>
              ))}

              <div className="flex gap-3 mt-4">
                {!auth ? (
                  <form onSubmit={handleAuthSubmit} className="flex gap-2 w-full">
                    <input
                      type="password"
                      placeholder="Contraseña"
                      value={password}
                      onChange={(e)=>setPassword(e.target.value)}
                      className="border px-3 py-2 rounded flex-1"
                    />
                    <button type="submit" className="px-3 py-2 bg-slate-900 text-white rounded">Editar</button>
                  </form>
                ) : (
                  <div className="flex flex-col gap-3 w-full">
                    <button onClick={() => setEditing(!editing)} className="inline-flex items-center gap-2 text-sm px-3 py-2 rounded-md bg-slate-100 hover:bg-slate-200">
                      <Edit3 size={16}/> {editing ? "Cerrar" : "Editar"}
                    </button>
                    {editing && (
                      <form onSubmit={handleSubmit} className="mt-4 space-y-3 border p-4 rounded-lg bg-slate-50">
                        <input type="text" placeholder="Título" value={form.title} onChange={(e)=>setForm({...form,title:e.target.value})} className="w-full border px-3 py-2 rounded" />
                        <textarea placeholder="Descripción" value={form.body} onChange={(e)=>setForm({...form,body:e.target.value})} className="w-full border px-3 py-2 rounded" />
                        <input type="date" value={form.date} onChange={(e)=>setForm({...form,date:e.target.value})} className="border px-3 py-2 rounded" />
                        <button type="submit" className="px-4 py-2 bg-slate-900 text-white rounded">Guardar</button>
                      </form>
                    )}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </section>

        {/* ABOUT */}
        <section id="about" className="bg-white rounded-2xl p-6 ring-1 ring-slate-100 shadow-sm">
          <SectionTitle icon={Users}>Quiénes somos</SectionTitle>
          <p className="text-slate-700 mb-4">{CMS.about.summary}</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {CMS.about.team.map((m) => (
              <div key={m.name} className="p-3 border rounded-lg">
                <div className="font-semibold">{m.name}</div>
                <div className="text-sm text-slate-500">{m.role}</div>
              </div>
            ))}
          </div>
        </section>

        {/* LAUNCHES */}
        <section id="launches" className="bg-white rounded-2xl p-6 ring-1 ring-slate-100 shadow-sm">
          <SectionTitle icon={Rocket}>Lanzamientos</SectionTitle>
          <div className="space-y-3">
            {CMS.launches.map((l) => (
              <div key={l.id} className="flex items-center justify-between border rounded-lg p-3">
                <div>
                  <div className="font-medium">{l.id}</div>
                  <div className="text-sm text-slate-500">{l.notes}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm">{l.date}</div>
                  <div className={`text-xs mt-1 px-2 py-1 rounded-full ${l.status === 'Planned' ? 'bg-amber-100 text-amber-800' : l.status === 'Testing' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>{l.status}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CONTACT */}
        <section id="contact" className="bg-white rounded-2xl p-6 ring-1 ring-slate-100 shadow-sm">
          <SectionTitle icon={() => <Users size={18} />}>Contacto</SectionTitle>
          <p className="text-sm text-slate-600">Email: <a className="underline" href={`mailto:${CMS.contact.email}`}>{CMS.contact.email}</a></p>
          <p className="text-sm text-slate-600">GitHub: <a className="underline" href={`https://${CMS.contact.github}`} target="_blank" rel="noopener noreferrer">{CMS.contact.github}</a></p>
        </section>
      </main>

      <footer className="border-t py-6 mt-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between text-sm text-slate-500">
          <div>© {new Date().getFullYear()} {CMS.siteTitle}. Todos los derechos reservados.</div>
          <div>Diseñado para GitHub Pages · Fácil edición</div>
        </div>
      </footer>
    </div>
  );
} 
